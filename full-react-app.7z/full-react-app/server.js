// Importálás
import express from "express";
import cors from "cors";
import { MongoClient, ObjectId } from "mongodb";
import dotenv from "dotenv";
import * as deepl from 'deepl-node';
import fs from 'fs';
import os from 'os';
import path from 'path';
import FormData from 'form-data';
import mime from 'mime-types';

// Alapvető konfigolások
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Változók meghatározása
let users;

// Adatbázis csatlakoztatása és beállítása
const client = new MongoClient(process.env.MONGO_URI);
await client.connect();
users = client.db(process.env.DB_NAME || "appdb").collection("users");
await users.createIndex({ username: 1 }, { unique: true });
await users.updateMany(
  { isAdmin: { $exists: false } },
  { $set: { isAdmin: false } }
);

const translations = client.db(process.env.DB_NAME || "appdb").collection("translations");

// ===== HELPER =====
// Admin-e?
const adminHeader = (req) => req.header("x-admin") === "1";

// ===== AUTH =====
// Regisztrálás (POST request)
app.post("/api/register", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) 
    return res.status(400).json({ ok: false, msg: "Hiányzó mező" });
  
  try {
    await users.insertOne({ username, password, isAdmin: false });
    res.json({ ok: true, msg: "Sikeres regisztráció" });
  } catch (e) {
    const code = e.code === 11000 ? 409 : 500;
    const msg = e.code === 11000 ? "Felhasználónév foglalt" : "Szerver hiba";
    res.status(code).json({ ok: false, msg });
  }
});

// Bejelentkezés (POST request)

app.post("/api/login", async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) 
    return res.status(400).json({ ok: false, msg: "Hiányzó mező" });

  const u = await users.findOne({ username, password });
  if (!u) return res.status(401).json({ ok: false, msg: "Hibás adatok" });

  res.json({ ok: true, msg: "Sikeres bejelentkezés", username, isAdmin: u.isAdmin });
});

// ===== ADMIN ENDPOINTOK =====

// Felhasználók lekérése (GET request)
app.get("/api/users", async (req, res) => {
  if (!adminHeader(req)) 
    return res.status(403).json({ ok: false, msg: "Nincs jogosultság" });

  const q = (req.query.q || "").trim();
  const filter = q ? { username: { $regex: q, $options: "i" } } : {};
  
  const docs = await users
    .find(filter, { projection: { password: 0 } })
    .sort({ username: 1 })
    .limit(100)
    .toArray();

  res.json({ ok: true, users: docs });
});

// Jelszó változtatása (PATCH request)
app.patch("/api/users/:username/password", async (req, res) => {
  if (!adminHeader(req)) 
    return res.status(403).json({ ok: false, msg: "Nincs jogosultság" });

  const { username } = req.params;
  const { password } = req.body || {};
  if (!password) return res.status(400).json({ ok: false, msg: "Hiányzó új jelszó" });

  const r = await users.updateOne({ username }, { $set: { password } });
  if (!r.matchedCount) return res.status(404).json({ ok: false, msg: "Nincs ilyen felhasználó" });

  res.json({ ok: true, msg: "Jelszó frissítve" });
});

// Admin jogosultság változtatása (PATCH request)
app.patch("/api/users/:username/admin", async (req, res) => {
  if (!adminHeader(req)) 
    return res.status(403).json({ ok: false, msg: "Nincs jogosultság" });

  const { username } = req.params;
  const { isAdmin } = req.body || {};
  if (typeof isAdmin !== "boolean") 
    return res.status(400).json({ ok: false, msg: "isAdmin boolean kell" });
  if (username === "admin" && !isAdmin) 
    return res.status(400).json({ ok: false, msg: "Alap admin nem vonható meg" });

  const r = await users.updateOne({ username }, { $set: { isAdmin } });
  if (!r.matchedCount) return res.status(404).json({ ok: false, msg: "Nincs ilyen user" });

  res.json({ ok: true, msg: isAdmin ? "Admin jog beállítva" : "Admin jog eltávolítva", isAdmin });
});

// Felhasználó törlése (DELETE request)
app.delete("/api/users/:username", async (req, res) => {
  if (!adminHeader(req)) 
    return res.status(403).json({ ok: false, msg: "Nincs jogosultság" });

  const { username } = req.params;
  if (username === "admin") return res.status(400).json({ ok: false, msg: "Alap admin nem törölhető" });

  const r = await users.deleteOne({ username });
  if (!r.deletedCount) return res.status(404).json({ ok: false, msg: "Nincs ilyen user" });

  res.json({ ok: true, msg: "Felhasználó törölve" });
});

// express routeolás
// Deepl API kulcs és kliens beállítása
const DEEPL_API_KEY = process.env.DEEPL_API_KEY || process.env.VITE_DEEPL_API_KEY;
if (!DEEPL_API_KEY) console.warn('Warning: DEEPL_API_KEY not set in environment');
const deeplClient = new deepl.DeepLClient(DEEPL_API_KEY);

// Convert language codes from frontend format to DeepL format
// DeepL source_lang: accepts base language codes like 'en', 'el', 'hu' (NO regional variants)
// DeepL target_lang: accepts codes with regions like 'en-US', 'pt-BR'

// 
const convertToDeepLLang = (code, isTarget = false) => {
  if (!code) return null;
  
  const normalized = code.toLowerCase();
  
  if (isTarget) {
    // target_lang: keep regional codes but fix capitalization
    if (normalized.includes('-')) {
      const parts = normalized.split('-');
      return parts[0] + '-' + parts[1].toUpperCase();
    }
    return normalized;
  } else {
    // source_lang: extract base language only (no regional variants)
    if (normalized.includes('-')) {
      return normalized.split('-')[0]; // e.g., 'en-US' -> 'en'
    }
    // Handle special cases for Chinese variants
    if (normalized === 'zh-hans' || normalized === 'zh-hant') return 'zh';
    return normalized;
  }
};


app.post('/translate', async (req, res) => {
    // A `req.body` egy json formátumot ad vissza, amiben text és target_lang kulcsok vannak. Ezt a `Translate`
    // gomb megnyomása után teszi
    const { text, source_lang, target_lang } = req.body;
    try {
        (async () => {
            // Convert language codes to DeepL format
            const deepLSourceLang = source_lang ? convertToDeepLLang(source_lang, false) : null;
            const deepLTargetLang = convertToDeepLLang(target_lang, true);
            
            console.log('Translating:', { source_lang, source_lang_deepl: deepLSourceLang, target_lang, target_lang_deepl: deepLTargetLang });
            
            // const result = await deeplClient.translateText('What\'s up?', null, 'fr');
            const result = await deeplClient.translateText(`${text}`, deepLSourceLang, deepLTargetLang);
            res.json({ translation: result.text });
        })();
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/save-translation', async (req, res) => {
    const { text, source_lang, target_lang, translation, userName } = req.body;
    if (!text || !translation || !target_lang) {
        return res.status(400).json({ ok: false, msg: "Hiányzó mező(k)" });
    }

  if (!userName) {
    return res.status(401).json({ ok: false, msg: 'Bejelentkezés szükséges a mentéshez' });
  }

    try {
        const doc = {
            text,
            translation,
            source_lang,
            target_lang,
            userName,
            createdAt: new Date()
        };
        await translations.insertOne(doc);
        res.json({ ok: true, msg: "Fordítás elmentve!" });
    } catch (err) {
        console.error(err);
        res.status(500).json({ ok: false, msg: "Mentés sikertelen" });
    }
});

// List translations (optional filter by user: /api/translations?user=matyi)
app.get('/api/translations', async (req, res) => {
  try {
    const q = (req.query.user || '').trim();
    const filter = q ? { userName: q } : {};
    const docs = await translations.find(filter).sort({ createdAt: -1 }).limit(200).toArray();
    res.json({ ok: true, translations: docs });
  } catch (err) {
    console.error('translations list error', err);
    res.status(500).json({ ok: false, msg: 'Hiba' });
  }
});

// Delete translation by id (body should contain username for ownership check)
app.delete('/api/translations/:id', async (req, res) => {
  const { id } = req.params;
  const { username } = req.body || {};
  if (!id) return res.status(400).json({ ok: false, msg: 'Hiányzó id' });

  try {
    // Use the collection to find the doc first
    const doc = await translations.findOne({ _id: new ObjectId(id) });
    if (!doc) return res.status(404).json({ ok: false, msg: 'Nincs ilyen fordítás' });

    // allow delete if admin header set or owner matches username
    if (!adminHeader(req) && doc.userName !== username) {
      return res.status(403).json({ ok: false, msg: 'Nincs jogosultság törölni' });
    }

    await translations.deleteOne({ _id: doc._id });
    res.json({ ok: true, msg: 'Törölve' });
  } catch (err) {
    console.error('delete translation error', err);
    res.status(500).json({ ok: false, msg: 'Hiba törlés közben' });
  }
});

// Upload a file (client sends base64) and return server path
app.post('/upload-document', async (req, res) => {
  const { filename, contentBase64 } = req.body || {};
  if (!filename || !contentBase64) return res.status(400).json({ ok: false, msg: 'Missing file' });
  const tmpPath = path.join(os.tmpdir(), `${Date.now()}_${path.basename(filename)}`);
  try {
    await fs.promises.writeFile(tmpPath, Buffer.from(contentBase64, 'base64'));
    res.json({ ok: true, path: tmpPath });
  } catch (err) {
    console.error('upload-document error', err);
    res.status(500).json({ ok: false, msg: err.message });
  }
});

// Translate a local server file using deeplClient.translateDocument
app.post('/translate-local', async (req, res) => {
  const { inputPath, outputFilename, source_lang, target_lang } = req.body || {};
  if (!inputPath || !outputFilename || !target_lang) return res.status(400).json({ ok: false, msg: 'Missing params' });
  try {
    const outputPath = path.join(os.tmpdir(), `${Date.now()}_${path.basename(outputFilename)}`);
    // Convert language codes to DeepL format
    const deepLSourceLang = source_lang ? convertToDeepLLang(source_lang, false) : null;
    const deepLTargetLang = convertToDeepLLang(target_lang, true);
    // deepl-node translateDocument expects inputPath and outputPath on disk
    const result = await deeplClient.translateDocument(inputPath, outputPath, deepLSourceLang, deepLTargetLang, {});
    // return the translated file as an attachment
    res.download(outputPath, path.basename(outputPath), async (err) => {
      try { await fs.promises.unlink(inputPath); } catch (e) { /* ignore */ }
      try { await fs.promises.unlink(outputPath); } catch (e) { /* ignore */ }
      if (err) console.error('download error', err);
    });
  } catch (err) {
    console.error('translate-local error', err && err.stack ? err.stack : err);
    const resp = { ok: false, msg: err.message || 'Fordítás sikertelen' };
    if (err && err.documentHandle) resp.documentHandle = err.documentHandle;
    res.status(500).json(resp);
  }
});
// Hallgatás az alap porton
app.listen(process.env.PORT || 3001, () => console.log("Backend szerver futtatva"));