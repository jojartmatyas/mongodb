export default async function(eleventyConfig) {
    eleventyConfig.setInputDirectory("src/md-docs");
    eleventyConfig.setOutputDirectory("src/components/docs");

    eleventyConfig.addShortcode("keyword", function (value = "") {
    return `<span x-text="query.keyword">${value}</span>`;
  });
}