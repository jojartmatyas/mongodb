// Kötelező csomag importok

import { useState, useEffect } from 'react';
import { languages_target, languages_source } from "./langs.json";
import Select from 'react-select';
import { BrowserRouter, Routes, Route, Navigate, Outlet } from 'react-router-dom';

// Stílusozás
import "./components/Site.scss"
import "./components/UserInterface.scss"
import "./components/ColorScheme.scss"

// Komponensek
import Fordito from './components/TranslateText';
import TranslateDocs from './components/TranslateDocs';
import TranslateImg from './components/TranslateImg';
import Footer from './components/Footer';
import About from './components/About';
import Documentation from './components/Documentation';
import Profile from './components/Profile';
import UserInterface from './components/UserInterface';
import MongoConnect from './components/MongoConnect';
import ModeSelect from './components/ModeSelect';
import Saved from './components/Saved';

function themeSwitch() {
  console.log("EZT ÁT KELL RAKNI KOMPONENSBE/MÁS FÁJLBA!")
}

function App() {
  const [user, setUser] = useState(() => {
    try {
      const s = localStorage.getItem('loggedUser');
      return s ? JSON.parse(s) : null;
    } catch (e) {
      return null;
    }
  });

  useEffect(() => {
    const onChange = () => {
      try {
        const s = localStorage.getItem('loggedUser');
        setUser(s ? JSON.parse(s) : null);
      } catch (e) {
        setUser(null);
      }
    };
    window.addEventListener('loggedUserChanged', onChange);
    return () => window.removeEventListener('loggedUserChanged', onChange);
  }, []);

  return (
    <>
    <BrowserRouter>
  <div className="app-shell">
    <UserInterface user={user} />

    <main className="app-main">
      <Routes>
  <Route path="/login" element={<MongoConnect />} />
        <Route path="/" element={<Navigate to="/translate" replace />} />

        <Route path="/translate" element={<><ModeSelect /><Outlet /></>}>
          <Route index element={<Fordito user={user} />} />
          <Route path="docs" element={<TranslateDocs user={user} />} />
          <Route path="img" element={<TranslateImg user={user} />} />
        </Route>

        <Route path="/about" element={<About />} />
        <Route path="/docs" element={<Documentation />} />
  <Route path="/profile" element={<Profile />} />
  <Route path="/saved" element={<Saved user={user} />} />
  </Routes>
    </main>

    <Footer />
  </div>
  </BrowserRouter>
    </>
  )
}

export default App;
