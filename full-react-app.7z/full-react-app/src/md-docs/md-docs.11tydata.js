export default {
	permalink: function ({ title }) {
		return `${this.slugify(title)}.html`;
	},
	layout: "default",
};