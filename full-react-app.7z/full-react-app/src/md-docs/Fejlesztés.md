---
title: Fejlesztés
tags:
  - fejlesztes
---
# React
## Strict mód eltávolítása
A **strict mód** React-ben egy komponens, mely a hibák észleléséért és egy stabilabb kódbázis kiépítéséért felelős. Egyszerűen: a **strict mód** kétszer logol ki minden változást, de sok esetben haszontalan. Ezt egy Reddit felhasználó írta:

>**Senior szoftvermérnök vagyok, és erősen ajánlom, hogy ne használd a strict mode-ot.** Ez megváltoztatja a dev és a production közötti környezetet, ami nem éri meg a macerát, ha valami félresikerül.
>
>A StrictMode elvileg arra van tervezve, hogy segítsen észlelni a hibákat helyileg (dev környezetben), mielőtt a kódot buildeled (npm run build paranccsal), de ezek a hibák inkább a React által preferált szemantikákkal kapcsolatosak, és nem is valódi hibák.

Azért, hogy ne kapjunk dupla logolást, vegyük ki a `main.jsx` fájlból a `<StrictMode>` komponenst. Ezután a `main.jsx` fájlunk így fog kinézni legegyszerűbben:

```jsx
import { createRoot } from 'react-dom/client'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
    <App />
)
```
## Polyfillek (HASZNÁLATLAN)

**A POLYFILLEKET MÁR NEM HASZNÁLJUK, VÉGÜL CORS ÉS EXPRESS CSOMAGOKKAL OLDOTTUK MEG A BACKEND MŰKÖDÉSÉT! A polyfillekkel semmiképp sem működött volna, egy alternatívát kellett találnunk, ami a lentebb említett cors és express használatát veszi igénybe.**

A polyfillek olyan Javascript kódok, melyek modern funkcionalitást nyújtanak régebbi böngészőknek. Mivel projektünk Vite-el fut, a Vite nem támogatja a Node alap funkcionalitásait, így az olyan csomagok, mint a `deepl-node` (melyek **megkövetelik** ezeket a funkcionalitásokat) nem fognak működni. Ezeket a csomagokat `polyfill`-elni kell, hogy a csomagok működjenek.

Mivel a Node funkcionalitásai hiányoznak, így ilyen hibaüzenetet kapunk a `deepl-node` importálása után:

>Uncaught TypeError: http.Agent is not a constructor

Hogy polyfilleljünk, a Vite-hez járó `vite-plugin-node-polyfills` csomagot fel kell telepítenünk:

`npm install --save-dev vite-plugin-node-polyfills` ...

Majd a Vite konfig fájlba importálnunk kell, és pluginként kell definiálnunk:


```js
import { defineConfig } from 'vite'
import { nodePolyfills } from 'vite-plugin-node-polyfills'
import react from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  plugins: [
    react(),
    nodePolyfills()
  ],
})
```

# Express és CORS haszna a projektben

Ahhoz, hogy a Same-Origin Policy ellen tudjunk dolgozni, szükségünk van az `cors` és `express` csomagokra.

```sh
npm install cors express
```

Mivel a `deepl-node` használata ezen projektben megköveteli, hogy `node.js`-t használjunk, így a React "natív" használatát el kell hanyagolnunk, mert a Node alap (core) moduljait nem veszi használatba. És mivel nem veszi használatba a Node alap moduljait, így a `deepl-node` sem működik egyszerűen. Hogy ezt kiküszöböljük, a `deepl-node` programot egy backend szerveren kell futtatni egy, a React-től különböző porton. Lényegében két szervert futtatunk egyszerre:
- A backend a 3001-es porton fog futni, ez intézi a DeepL-es API kérelmeket, és elküldi a frontendre, ami a Vite-nél alapjáraton 5173
- A frontend (5173) fogadja a beérkező kérelmeket, majd továbbítja a felhasználónak. A Same-Origin Policy miatt lehetetlen lenne más portról érkező adat fogadása, de a `cors` ezt megoldja. 

Ahhoz, hogy importáljuk, majd inicializáljuk a fent említett csomagokat, és működésre bírjuk őket egymással (`dotenv`, `express` valamint `cors`), beírtuk a következőket a `server.js` fájlba, amelyet a `package.json` mellé helyeztünk:

```js
// Csomagok importálása
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

// dotenv beállítása
dotenv.config();

// CORS és Express inicializálása
const app = express();
app.use(cors());
app.use(express.json());
```
## dotenv változók elérése
A `.env` fájlt a gyökérkönyvtárba kell helyezni, azaz a `package.json` fájl mellé. A `.env` tartalma:

```.env
VITE_DEEPL_API_KEY="apikulcs"
```

A `.env` fájl változóit a következő paranccsal érhetjük el:

```jsx
...
const env = await import.meta.env
export const DEEPL_API_KEY = (env.VITE_DEEPL_API_KEY)
...
```

Ez minél hamarabb definiáljuk az `App.jsx` fájlban. Ha ezt kilogoljuk, megkapjuk az API kulcsot. Hasonlóan kaphatjuk meg a többi változót is.
# Elérhető forrás/cél nyelvek listázása
Ahhoz, hogy az elérhető forrás/cél nyelveket listázzuk, a `getTargetLanguages` vagy `getSourceLanguages` metódusokat kell meghívnunk. Ez JSON formátumban kilogolja a konzolra, amit azért csináltam, hogy aztán egy `langs.json` nevű fájlba tehessem a forrás/cél nyelveket (gyorsabb betöltés érdekében, az API call helyett)

```js
const targetLanguages = await deeplClient.getTargetLanguages();
for (let i = 0; i < targetLanguages.length; i++) {
    const lang = targetLanguages[i];
    console.log(`{"name": "${lang.name}", "code": "${lang.code}"},`);
}
```

