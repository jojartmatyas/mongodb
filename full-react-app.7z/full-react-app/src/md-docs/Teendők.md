---
title: Teendők
---

# Fordító (Béla)
- Fordító oldal stílusozása (SCSS)
- Formality/clarity implementálása
- Dokumentáció kialakítása (ezt lehet 11ty-vel)
- Detect language alapból
- Fordítás mentése
- Google translate-ről a különböző fülek leszedése

# Adatbázis (Matyi)

# Legvégén
Miután mindketten végeztünk az egyes részekkel, mergeljük őket.