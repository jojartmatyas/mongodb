---
title: Csomagok
---
# Szükséges csomagok
Szükséges csomagok, hogy futtassuk a projektet:
- deepl-node
- dotenv
- express
- cors
- mongoose
- 11ty
- react-router-doms

Az összes többi dev-dependency, valamint a `react` és `react-dom` függőségek, ezek a Vite inicializálásál automatikusan feltelepülnek.
## dotenv
Szükséges, hogy `.env` fájlból tudjunk olvasni. Így az API kulcsaink nem kerülnek ki a forráskód feltöltésével.
## deepl-node
A `deepl-node` csomag ahhoz szükséges, hogy a Deepl saját kliens könyvtárához hozzáférjünk. Így tudunk majd az API-val interaktálni.

## mongoose
A `mongoose` könyvtárral tudunk mind online, mind offline MongoDB adatbázisokhoz hozzáférni.