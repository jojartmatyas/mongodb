import React, { useEffect, useState, useRef } from 'react';
import LanguageSelector, { useLanguageSelector } from './LanguageSelector';

const Fordito = ({ user }) => {
  const [text, setText] = useState('');
  const [translated, setTranslated] = useState('');
  const [loading, setLoading] = useState(false);
  const [voices, setVoices] = useState([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const username = user?.username || '';
  const [toast, setToast] = useState(null); // { msg, type }

  const showToast = (msg, type = 'info', duration = 2500) => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), duration);
  };
  const utterRef = useRef(null);

  const {
    sourceLang,
    targetLang,
    setSourceLang,
    setTargetLang,
    sourceOptions,
    targetOptions,
    swapLanguages,
  } = useLanguageSelector();

  async function handleTranslate() {
    setLoading(true);
    setTranslated('');
    try {
      const res = await fetch('http://localhost:3001/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          source_lang: sourceLang?.code,
          target_lang: targetLang?.code,
          userName: username,
        }),
      });
      const data = await res.json();
      setTranslated(data.translation || '');
    } catch (err) {
      setTranslated('Error: ' + err.message);
    }
    setLoading(false);
  }

  useEffect(() => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    const loadVoices = () => {
      const v = window.speechSynthesis.getVoices() || [];
      setVoices(v);
    };

    loadVoices();
    window.speechSynthesis.onvoiceschanged = loadVoices;

    return () => {
      if (window.speechSynthesis.onvoiceschanged === loadVoices) {
        window.speechSynthesis.onvoiceschanged = null;
      }
      window.speechSynthesis.cancel();
    };
  }, []);

  const findVoiceFor = (langCode) => {
    if (!langCode) return null;
    const base = langCode.split('-')[0];
    let v = voices.find((x) => x.lang && x.lang.toLowerCase() === langCode.toLowerCase());
    if (v) return v;
    v = voices.find((x) => x.lang && x.lang.toLowerCase().startsWith(base.toLowerCase()));
    if (v) return v;
    v = voices.find((x) => x.lang && x.lang.toLowerCase().startsWith('en'));
    return v || voices[0] || null;
  };

  const speakText = (textToSpeak, langCode) => {
    if (!textToSpeak) return;
    if (typeof window === 'undefined' || !window.speechSynthesis) return;

    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(textToSpeak);
    utter.lang = (langCode && langCode.split('-')[0]) || undefined;
    const voice = findVoiceFor(langCode);
    if (voice) utter.voice = voice;
    utter.rate = 0.2;
    utter.pitch = 0.1;
    utter.onstart = () => setIsSpeaking(true);
    utter.onend = () => setIsSpeaking(false);
    utter.onerror = () => setIsSpeaking(false);
    utterRef.current = utter;
    window.speechSynthesis.speak(utter);
  };

  const stopSpeaking = () => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  async function switchLanguages() {
    const prevSource = sourceLang;
    const prevTarget = targetLang;

    const findMatch = (opt, list) => {
      if (!opt) return null;
      let m = list.find((o) => o.code === opt.code);
      if (m) return m;
      const base = opt.code.split('-')[0];
      m = list.find((o) => o.code && o.code.split('-')[0] === base);
      if (m) return m;
      m = list.find((o) => o.name === opt.name);
      return m || null;
    };

    const newSource = findMatch(prevTarget, sourceOptions) || prevTarget;
    const newTarget = findMatch(prevSource, targetOptions) || prevSource;

    setSourceLang(newSource);
    setTargetLang(newTarget);
  }

  useEffect(() => {
    if (!text) return;

    const timer = setTimeout(() => {
      handleTranslate();
    }, 1000);

    return () => clearTimeout(timer);
  }, [text]);

  return (
    <div id="fordito" className="centered">
      <div className="translateContainer">
        <LanguageSelector
          sourceLang={sourceLang}
          targetLang={targetLang}
          setSourceLang={setSourceLang}
          setTargetLang={setTargetLang}
          sourceOptions={sourceOptions}
          targetOptions={targetOptions}
          swapLanguages={swapLanguages}
        />
        <div className="langSTextArea">
          <button className="clear-btn" title="Törlés" onClick={() => { setText(''); setTranslated(''); }}>✕</button>
          <div style={{ width: '40px', position: 'absolute', right: '0', bottom: 0, margin: '0 10px 10px 0' }}>
            <button title="Hallgatás" onClick={() => speakText(text, sourceLang?.code)} disabled={!text || isSpeaking}>🔊</button>
          </div>
          <textarea
            name="text"
            rows={4}
            maxLength={1000}
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder='Írja be a fordításra kívánt szöveget.'
          />
        </div>
        <div className="langTTextArea" style={{ position: 'relative' }}>
          <div style={{ display: 'flex', gap: 8, position: 'absolute', right: '0', bottom: 0, margin: '0 10px 10px 0' }}>
            <button title="Hallgatás" onClick={() => speakText(translated, targetLang?.code)} disabled={!translated || isSpeaking}>🔊</button>

            <button
              title={!username ? 'Jelentkezz be a mentéshez' : 'Mentés'}
              onClick={async () => {
                if (!username) {
                  showToast('Előbb jelentkezz be a mentéshez.', 'warning');
                  return;
                }
                try {
                  const res = await fetch('http://localhost:3001/save-translation', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      text,
                      translation: translated,
                      source_lang: sourceLang?.code,
                      target_lang: targetLang?.code,
                      userName: username,
                    }),
                  });
                  const data = await res.json();
                  showToast(data.msg || (data.ok ? 'Mentve' : 'Hiba'), data.ok ? 'success' : 'error');
                } catch (err) {
                  showToast('Mentés sikertelen: ' + err.message, 'error');
                }
              }}
              style={{ background: 'none', border: 'none', padding: 0, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
            >
              <img
                src="https://res.cloudinary.com/dguf0juur/image/upload/v1763637651/bookmark_24dp_E3E3E3_FILL0_wght400_GRAD0_opsz24_rv1m3m.svg"
                alt="Mentés"
                style={{ display: 'block', opacity: username ? 1 : 0.6 }}
              />
            </button>
          </div>
          <div>{translated}</div>
        </div>
      </div>
        {/* Toast */}
        {toast && (
          <div style={{
            position: 'fixed',
            top: 72,
            left: '50%',
            transform: 'translateX(-50%)',
            background: toast.type === 'error' ? '#b30000' : toast.type === 'success' ? '#168000' : toast.type === 'warning' ? '#ff7a00' : '#333',
            color: '#fff',
            padding: '10px 14px',
            borderRadius: 6,
            boxShadow: '0 6px 18px rgba(0,0,0,0.25)',
            zIndex: 9999,
            fontSize: 14,
            maxWidth: '80%',
            minWidth: 160,
            textAlign: 'center',
            transition: 'opacity 220ms ease, transform 220ms ease'
          }}>{toast.msg}</div>
        )}
 
    </div>
  );
};

export default Fordito;