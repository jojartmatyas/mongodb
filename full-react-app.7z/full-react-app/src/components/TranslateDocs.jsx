import React, { useRef, useState } from 'react';
import LanguageSelector, { useLanguageSelector } from './LanguageSelector';

const TranslateDocs = () => {
  const fileRef = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [serverPath, setServerPath] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const {
    sourceLang,
    targetLang,
    setSourceLang,
    setTargetLang,
    sourceOptions,
    targetOptions,
    swapLanguages,
  } = useLanguageSelector({ initialSource: 'hu', initialTarget: 'en-US' });
  const [translatedText, setTranslatedText] = useState('');

  function onBrowse() { fileRef.current?.click(); }
    async function onFile(e) {
      try {
        const f = e.target.files && e.target.files[0];
        setSelectedFile(f || null);
        setServerPath(null);
        setMessage('');
        setTranslatedText('');
        // wait for the user to click "Fordítás" to upload/translate
      } catch (err) {
        console.error('onFile error', err);
        setMessage('Hiba a fájl kiválasztásakor: ' + (err && err.message));
      }
    }

  async function upload() {
    // Accept a file parameter to avoid relying on stale state
    // Signature kept for backward compatibility
    return await uploadFile(selectedFile);
  }

  async function uploadFile(fileParam) {
      const fileToUpload = fileParam || selectedFile;
      if (!fileToUpload) {
        setMessage('Válasszon fájlt');
        return null;
      }
      setBusy(true); setMessage('Feltöltés...');
      try {
        const data = await fileToBase64(fileToUpload);
        const base64 = data.split(',')[1];
        const resp = await fetch('http://localhost:3001/upload-document', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ filename: fileToUpload.name, contentBase64: base64 })
        });
        const json = await resp.json().catch(() => null);
        if (!resp.ok) {
          console.error('upload-document response error', resp.status, json);
          setMessage('Feltöltési hiba: ' + (json && (json.msg || JSON.stringify(json)) || resp.status));
          setBusy(false);
          return null;
        }
        setServerPath(json.path); setMessage('Feltöltve: ' + json.path); setBusy(false);
        return json.path;
      } catch (err) { console.error('uploadFile error', err); setMessage('Hiba: ' + err.message); setBusy(false); return null; }
  }

  async function translate(serverPathParam) {
    const pathToUse = serverPathParam || serverPath;
    if (!pathToUse) return setMessage('Előbb töltse fel a fájlt (Upload)');
    setBusy(true); setMessage('Fordítás...');
    try {
      const body = { inputPath: pathToUse, outputFilename: `translated_${selectedFile?.name || 'out'}`, source_lang: sourceLang?.code, target_lang: targetLang?.code };
      const resp = await fetch('http://localhost:3001/translate-local', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      if (!resp.ok) { const txt = await resp.text(); setMessage('Fordítási hiba: ' + txt); setBusy(false); return; }
      const blob = await resp.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `translated_${selectedFile?.name || 'out'}`; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
      setMessage('Kész — letöltve');
      setTranslatedText('A fájl le lett fordítva és letöltve.');
      setBusy(false);
    } catch (err) { setMessage('Hiba: ' + err.message); setBusy(false); }
  }

  async function handleTranslateClick() {
    if (!selectedFile) {
      setMessage('Válasszon fájlt');
      return;
    }
    setMessage('');
    try {
      // upload the currently selected file (pass directly to avoid stale state)
      const path = await uploadFile(selectedFile);
      if (!path) return;
      // translate the uploaded file
      await translate(path);
    } catch (err) {
      console.error('handleTranslateClick error', err);
      setMessage('Hiba a fordítás indításakor: ' + (err && err.message));
    }
  }

  function clearSelected() {
    setSelectedFile(null);
    setServerPath(null);
    setMessage('');
    setTranslatedText('');
    if (fileRef.current) fileRef.current.value = '';
  }

  function fileToBase64(file) {
    return new Promise((res, rej) => {
      const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file);
    });
  }

  return (
    <div id="fordito" className='centered'>
    <div className='translateContainer translate-file'>
      <LanguageSelector
        sourceLang={sourceLang}
        targetLang={targetLang}
        setSourceLang={setSourceLang}
        setTargetLang={setTargetLang}
        sourceOptions={sourceOptions}
        targetOptions={targetOptions}
        swapLanguages={swapLanguages}
      />

      <input ref={fileRef} type="file" accept=".docx,.pdf,.txt,.pptx" style={{ display: 'none' }} onChange={onFile} />
      {!selectedFile ? (
        <div className='browse-files'>
          <button onClick={onBrowse}>Fájlok böngészése</button>
          <div style={{ marginTop: 12 }}>{message}</div>
        </div>
      ) : (
        <div style={{ marginTop: 12, width: '100%'}}>
          <div className="card" style={{ padding: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <img src="/imgs/icons/file.svg" alt="file" style={{ width: 40, height: 40 }} />
              <div>
                <div style={{ fontWeight: 600 }}>{selectedFile.name}</div>
                <div style={{ fontSize: 12, color: '#666' }}>{(selectedFile.size / 1024).toFixed(1)} KB</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={handleTranslateClick} disabled={busy}>{busy ? 'Fut...' : 'Fordítás'}</button>
              <button onClick={clearSelected} title="Törlés">✕</button>
            </div>
          </div>
          <div style={{ marginTop: 12 }}>{message}</div>
        </div>
      )}

    </div>
    </div>
  );
};

export default TranslateDocs;