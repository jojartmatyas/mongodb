import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Profile = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const saved = localStorage.getItem('loggedUser');
    if (saved) setUser(JSON.parse(saved));
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('loggedUser');
    setUser(null);
    window.dispatchEvent(new Event('loggedUserChanged'));
    navigate('/');
  };

  if (!user) {
    return (
      <div id="profile" className='centered'>
        <h2>Nem vagy bejelentkezve.</h2>
        <a href="/login">Bejelentkezés</a>
      </div>
    );
  }

  return (
    <div id="profile" className='centered'>
      <h2 style={{textAlign: "center"}}>{user.username}</h2>
      {user.isAdmin ? "Igen, rendelkezik azzal a szép kedves admin joggal :-)" : ""}
      <p>Profilkép:</p>
      <button className="primary-btn" onClick={handleLogout} style={{marginLeft: "auto", marginRight: "auto", display: "block"}}>Kijelentkezés</button>
    </div>
  );
}

export default Profile