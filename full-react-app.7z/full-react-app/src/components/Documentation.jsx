import React, { useEffect } from 'react'
import HtmlComponent from './HtmlComponent'
import './Documentation.scss'
import './prism.css'

const Documentation = () => {

  useEffect(() => {
    const script = document.createElement('script');
    script.src = "/prism.js";
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    }
  }, [])

  return (
    <div id="documentation">
      <script src="/public/prism.js"></script>
      <h1 style={{border: 'none'}}>Dokumentáció</h1>
      <HtmlComponent file="csomagok"/>
      <HtmlComponent file="fejlesztes"/>
      <HtmlComponent file="futtatas"/>
      <HtmlComponent file="teendok"/>
    </div>
  )
}

export default Documentation