import React, { useEffect, useState } from 'react';

const HtmlComponent = ({ file }) => {
  const [content, setContent] = useState('');

  useEffect(() => {
    fetch(`/src/components/docs/${file}.html`)
      .then((res) => res.text())
      .then((html) => setContent(html))
      .catch((err) => setContent(`<p>Nem sikerült betölteni a ${file}.html fájlt</p>`));
  }, [file]);

  return <div className="note" dangerouslySetInnerHTML={{ __html: content }} />;
};

export default HtmlComponent;