import React, { useState } from 'react';
import Select from 'react-select';
import { languages_target, languages_source } from "../langs.json";
import { GoArrowSwitch } from "react-icons/go";

export function useLanguageSelector({ initialSource = 'hu', initialTarget = 'en-US' } = {}) {
  const [sourceOptions] = useState(languages_source);
  const [targetOptions] = useState(languages_target);

  const [sourceLang, setSourceLang] = useState(
    sourceOptions.find(l => l.code === initialSource) || sourceOptions[0] || null
  );
  const [targetLang, setTargetLang] = useState(
    targetOptions.find(l => l.code === initialTarget) || targetOptions[0] || null
  );

  const findMatch = (opt, list) => {
    if (!opt) return null;
    let m = list.find(o => o.code === opt.code);
    if (m) return m;
    const base = opt.code && opt.code.split ? opt.code.split('-')[0] : null;
    if (base) {
      m = list.find(o => o.code && o.code.split('-')[0] === base);
      if (m) return m;
    }
    m = list.find(o => o.name === opt.name);
    return m || null;
  };

  function swapLanguages() {
    const prevSource = sourceLang;
    const prevTarget = targetLang;

    const newSource = findMatch(prevTarget, sourceOptions) || prevTarget;
    const newTarget = findMatch(prevSource, targetOptions) || prevSource;

    setSourceLang(newSource);
    setTargetLang(newTarget);
  }

  function resetLanguages() {
    setSourceLang(sourceOptions.find(l => l.code === initialSource) || sourceOptions[0] || null);
    setTargetLang(targetOptions.find(l => l.code === initialTarget) || targetOptions[0] || null);
  }

  return {
    sourceLang,
    targetLang,
    setSourceLang,
    setTargetLang,
    sourceOptions,
    targetOptions,
    swapLanguages,
    resetLanguages,
  };
}

// Presentational component - controlled. Parent should provide state + setters from the hook.
const LanguageSelector = ({
  sourceLang,
  targetLang,
  setSourceLang,
  setTargetLang,
  sourceOptions,
  targetOptions,
  swapLanguages,
  sourcePlaceholder = 'Forrásnyelv',
  targetPlaceholder = 'Célnyelv',
}) => {
  return (
    <div className="langSelect">
      <div style={{}} className="langS">
        <Select
          options={sourceOptions}
          getOptionLabel={option => option.name}
          getOptionValue={option => option.code}
          value={sourceLang}
          onChange={setSourceLang}
          placeholder={sourcePlaceholder}
          isSearchable
        />
      </div>
      <div className="langSwitch">
        <GoArrowSwitch style={{ height: '100%', cursor: 'pointer' }} onClick={swapLanguages} />
      </div>
      <div style={{}} className="langT">
        <Select
          options={targetOptions}
          getOptionLabel={option => option.name}
          getOptionValue={option => option.code}
          value={targetLang}
          onChange={setTargetLang}
          placeholder={targetPlaceholder}
          isSearchable
        />
      </div>
    </div>
  );
};

export default LanguageSelector;
