import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Fordito from "./TranslateText";
import "./MongoConnect.scss";

const MongoConnect = () => {
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [msg, setMsg] = useState("");
  const [loading, setLoading] = useState(false);
  const [loggedUser, setLoggedUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [search, setSearch] = useState("");
  const [adminMsg, setAdminMsg] = useState("");
  const path = window.location.pathname;
  const isLogin = mode === "login";
  const navigate = useNavigate();

  // Betöltés / mentés localStorage-ből
  useEffect(() => {
    const saved = localStorage.getItem("loggedUser");
    if (saved) setLoggedUser(JSON.parse(saved));
  }, []);

  useEffect(() => {
    loggedUser
      ? localStorage.setItem("loggedUser", JSON.stringify(loggedUser))
      : localStorage.removeItem("loggedUser");
  }, [loggedUser]);

  // Admin esetén felhasználók lekérése
  useEffect(() => {
    if (loggedUser?.isAdmin) fetchUsers();
  }, [loggedUser, search]);

  async function api(path, method = "GET", body, admin = false) {
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body) opts.body = JSON.stringify(body);
    if (admin) opts.headers["x-admin"] = "1";
    const res = await fetch(path, opts);
    return res.json();
  }

  async function fetchUsers() {
    const res = await api(
      "/api/users" + (search ? "?q=" + encodeURIComponent(search) : ""),
      "GET",
      null,
      true
    );
    res.ok ? setUsers(res.users) : setAdminMsg(res.msg || "Hiba");
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!username || !password) return setMsg("Tölts ki mindent.");
    setLoading(true);
    try {
      const endpoint = isLogin ? "/api/login" : "/api/register";
      const res = await api(endpoint, "POST", { username, password });
      setMsg(res.msg || (res.ok ? "OK" : "Hiba"));
      if (res.ok && isLogin) {
  const newUser = { username: res.username, isAdmin: res.isAdmin };
  setLoggedUser(newUser);
  // persist immediately so other parts of the app can read it
  try { localStorage.setItem('loggedUser', JSON.stringify(newUser)); } catch(e) {}
        setUsername("");
        setPassword("");
  // notify other components that the logged user changed
  window.dispatchEvent(new Event('loggedUserChanged'));
        // Átirányítás a főoldalra
        setTimeout(() => navigate("/"), 500);
      } else if (res.ok) {
        setMode("login");
        setPassword("");
      }
    } catch {
      setMsg("Hálózati hiba");
    } finally {
      setLoading(false);
    }
  }

  // ---- Admin műveletek ----
  const toggleAdmin = async (u) => {
    const r = await api(`/api/users/${u}/toggle-admin`, "PATCH", null, true);
    setAdminMsg(r.msg);
    if (r.ok) fetchUsers();
  };

  const changePass = async (u) => {
    const pw = prompt(`Új jelszó: ${u}`);
    if (!pw) return;
    const r = await api(`/api/users/${u}/password`, "PATCH", { password: pw }, true);
    setAdminMsg(r.msg);
  };

  const delUser = async (u) => {
    if (!confirm(`Törlöd: ${u}?`)) return;
    const r = await api(`/api/users/${u}`, "DELETE", null, true);
    setAdminMsg(r.msg);
    if (r.ok) fetchUsers();
  };

  // ---- Render blokkok ----
  if (path === "/admin") {
    if (!loggedUser)
      return <MsgCard title="Admin" msg="Előbb jelentkezz be." link="/login" />;

    if (!loggedUser.isAdmin)
      return <MsgCard title="Nincs jogod" msg="Ez az oldal csak adminoknak." link="/login" />;

    return (
      <div className="page-wrapper">
          <h1 className="title">Admin panel</h1>
          <p style={{ textAlign: "center", fontWeight: 600, color: "#ff7a00" }}>
            Bejelentkezve: {loggedUser.username} (admin)
          </p>
          <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
            <input
              style={{ flex: 1 }}
              placeholder="Keresés..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button className="primary-btn" onClick={fetchUsers}>Frissít</button>
            <button className="primary-btn" onClick={() => { setLoggedUser(null); try{ localStorage.removeItem('loggedUser'); }catch(e){} window.dispatchEvent(new Event('loggedUserChanged')) }}>Kilépés</button>
            <a href="/"><button className="primary-btn" style={{ background: "#ffb347" }}>Főoldal</button></a>
          </div>
          {adminMsg && <p style={{ color: "#b30000", fontWeight: 600 }}>{adminMsg}</p>}
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <tbody>
              {users.map((u) => (
                <tr key={u.username}>
                  <td>{u.username}</td>
                  <td>{u.isAdmin ? "Igen" : "Nem"}</td>
                  <td style={{ display: "flex", gap: 4 }}>
                    <button style={miniBtn} onClick={() => toggleAdmin(u.username)} disabled={u.username === "admin"}>
                      {u.isAdmin ? "Admin elvesz" : "Admin ad"}
                    </button>
                    <button style={miniBtn} onClick={() => changePass(u.username)}>Jelszó</button>
                    <button style={{ ...miniBtn, background: "#c92a2a" }} onClick={() => delUser(u.username)} disabled={u.username === "admin"}>
                      Törlés
                    </button>
                  </td>
                </tr>
              ))}
              {!users.length && <tr><td colSpan={3} style={{ textAlign: "center" }}>Nincs találat</td></tr>}
            </tbody>
          </table>
        </div>
    );
  }

  // Itt a JSON response-ból megjelenített értéket adja, nme az alattam levő MsgCard komponenst.
  // Ez a server.js ~58. sora.

  if (loggedUser) {
      // <MsgCard
      //   msg="Sikeres bejelentkezés."
      //   extra={loggedUser.isAdmin && <a href="/admin" className="link-btn">➡ Admin panel</a>}
      //   button={{ text: "Kilépés", onClick: () => setLoggedUser(null) }}
      // />
  }

  return (
    <div className="page-wrapper">
      <div>
        <h1 className="title">{isLogin ? "Jelentkezz be a Nudli fordítóba" : "Regisztrálj a Nudlira"}</h1>
        <form className="form" onSubmit={handleSubmit}>
          <label className="field">
            <span style={{ display: "block", marginBottom: 10 }}>Felhasználónév</span>
            <input value={username} onChange={(e) => setUsername(e.target.value)} />
          </label>
          <label className="field">
            <span style={{ display: "block", marginBottom: 10 }}>Jelszó</span>
            <div style={{ position: "relative" }}>
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                style={{ paddingRight: 70 }}
              />
              <button
                type="button"
                className="link-btn"
                style={{ position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)", fontSize: 12, padding: 0 }}
                onClick={() => setShowPassword((v) => !v)}
              >
                {showPassword ? "Elrejt" : "Mutat"}
              </button>
            </div>
          </label>
          <button className="primary-btn" disabled={loading}>
            {loading ? "Küldés..." : isLogin ? "Belépés" : "Regisztrálok"}
          </button>
        </form>
        {msg && <p style={{ textAlign: "center", color: msg.includes("Sikeres") ? "#168000" : "#b30000" }}>{msg}</p>}
        <div className="switcher">
          {isLogin ? (
            <p>
              Nincs még fiókod? <button type="button" className="link-btn" onClick={() => setMode("register")}>Regisztráció</button>
            </p>
          ) : (
            <p>
              Van már fiókod? <button type="button" className="link-btn" onClick={() => setMode("login")}>Bejelentkezés</button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

// Reusable komponensek
function MsgCard({ title, msg, link, extra, button }) {
  return (
    <div className="page-wrapper">
      <div className="card">
        {title && <h1 className="title">{title}</h1>}
        <p style={{ textAlign: "center", color: "#ff7a00", fontWeight: 600 }}>{msg}</p>
        {extra}
        {link && <a href={link} className="link-btn">Vissza</a>}
        {button && <button className="primary-btn" onClick={button.onClick}>{button.text}</button>}
      </div>
    </div>
  );
}

const miniBtn = {
  background: "#ff922b",
  border: "none",
  color: "#fff",
  padding: "4px 8px",
  borderRadius: 4,
  cursor: "pointer",
  fontSize: "12px",
  fontWeight: 600,
};

export default MongoConnect