import React from "react";
import "./About.scss";

const DevCard = ({ img, name, role, description }) => {
  return (
    <div className="profile">
      <img src={img} alt={name} />
      <div className="profile-content">
        <div className="role">{role}</div>
        <div className="name">{name}</div>
        <div className="description">{description}</div>
      </div>
    </div>
  );
};

const About = () => {
  const teamMembers = [
    {
      name: "Gyenes Béla",
      role: "Fordítás",
      description: "A fordító részért felelős.",
      img: "https://res.cloudinary.com/dguf0juur/image/upload/v1763629179/bela_ceop6q.png",
    },
    {
      name: "Jójárt Mátyás",
      role: "Adatbázis",
      description: "Az adatbázis részért felelős.",
      img: "https://res.cloudinary.com/dguf0juur/image/upload/v1763629179/matyi_wzqvh0.png",
    },
  ];

  return (
    <div id="about" className="team-container">
      <div className="profiles">
        {teamMembers.map((member, index) => (
          <DevCard
            key={index}
            img={member.img}
            name={member.name}
            role={member.role}
            description={member.description}
          />
        ))}
      </div>
    </div>
  );
};

export default About;
