import React, { useEffect, useState, useRef } from 'react';
import "./UserInterface.scss"
import { Link } from 'react-router-dom';

const THEMES = ['light', 'dark', 'auto'];

const UserInterface = ({ user }) => {
  const [open, setOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('site-theme') || 'auto'; } catch (e) { return 'auto'; }
  });
  const menuRef = useRef(null);

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'auto') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', theme);
    try { localStorage.setItem('site-theme', theme); } catch (e) {}
  }, [theme]);

  useEffect(() => {
    function onDocClick(e) {
      if (menuRef.current && !menuRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('click', onDocClick);
    return () => document.removeEventListener('click', onDocClick);
  }, []);

  function selectTheme(t) { if (THEMES.includes(t)) { setTheme(t); setOpen(false); } }
  function toggleMenu(e) { e.stopPropagation(); setOpen(v => !v); }

  function iconFor(current) {
    if (current === 'dark') return (<img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629115/dark_rk0mtp.svg" alt="" style={{width: "16px", height: "16px"}} />);
    if (current === 'light') return (<img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629114/light_cg1wqe.svg" alt="" style={{width: "16px", height: "16px"}} />);
    return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>);
  }

  return (
    <div id="ui">
      <header>
        <div className="container">
          <div className="header-content">
            <div className="header-left">
              <Link to="/" className="logo">
                <div className="logo-icon" style={{margin: '0 10px 0 10px', background: 'none'}}>
                  <img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629304/nudli-text_kfiotq.svg" alt="" />
                </div>
                <span id="site-title">Nudli fordító</span>
              </Link>
              <nav id="main-nav" className={mobileOpen ? 'open' : ''}>
              <div className="nav-links">
                <div className="nav-left">
                  <Link to="/about" onClick={() => setMobileOpen(false)}>Rólunk</Link>
                  <Link to="/docs" onClick={() => setMobileOpen(false)}>Dokumentáció</Link>
                  <Link to="/saved" onClick={() => setMobileOpen(false)}>Mentett</Link>
                </div>

                <div className="nav-right">
                </div>
              </div>
            </nav>
            </div>
            <div className="header-right">
              <div className="theme-dropdown" ref={menuRef}>
                <button id="theme-toggle" className="theme-toggle" onClick={toggleMenu} aria-expanded={open} aria-haspopup="menu" title="Téma választás">
                  <span id="current-theme-icon">{iconFor(theme)}</span>
                </button>
                <div id="theme-menu" className={`theme-menu ${open ? 'show' : ''}`}>
                  <button className={`theme-option ${theme==='light'? 'active':''}`} onClick={() => selectTheme('light')} data-theme="light">
                    <img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629114/light_cg1wqe.svg" alt="" style={{width: "16px", height: "16px"}} /> Világos
                  </button>
                  <button className={`theme-option ${theme==='dark'? 'active':''}`} onClick={() => selectTheme('dark')} data-theme="dark">
                    <img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629115/dark_rk0mtp.svg" alt="" style={{width: "16px", height: "16px"}} /> Sötét
                  </button>
                  <button className={`theme-option ${theme==='auto'? 'active':''}`} onClick={() => selectTheme('auto')} data-theme="auto">
                    <img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629112/alapertelmezett_swmrmx.svg" alt="" style={{width: "16px", height: "16px"}} /> Alapértelmezett
                  </button>
                </div>
              </div>

              {user ? (
                <Link to="/profile" onClick={() => setMobileOpen(false)} className="profile-link">Profil</Link>
              ) : (
                <div className="login-inline">
                  <div className="login-info">
                    <div className="login-title">Nem vagy bejelentkezve.</div>
                    <div className="login-sub">Kérlek jelentkezz be, hogy megtekinthesd és elmenthesd a fordításokat.</div>
                  </div>
                  <Link to="/login" className="login-btn" onClick={() => setMobileOpen(false)}>Bejelentkezés</Link>
                </div>
              )}

              <a href="#" id="menu-download" className="download-btn no-underline" onClick={() => setMobileOpen(false)}>
                <img src="https://res.cloudinary.com/dguf0juur/image/upload/v1763629113/download_ve52pj.svg" alt="" style={{width: "16px", height: "16px"}} />
                <span>App letöltése</span>
              </a>

              <button
                className={`mobile-toggle hamburger ${mobileOpen ? 'is-active' : ''}`}
                onClick={() => setMobileOpen(v => !v)}
                aria-label="Menü"
                aria-expanded={mobileOpen}
              >
                <span className="bar" />
                <span className="bar" />
                <span className="bar" />
              </button>
            </div>
          </div>
        </div>
      </header>
    </div>
  );
}

export default UserInterface;