import React, { useRef, useState } from 'react';
import Tesseract, { createWorker } from 'tesseract.js';
import LanguageSelector, { useLanguageSelector } from './LanguageSelector';

const TranslateImg = () => {
  const fileRef = useRef(null);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const { sourceLang, targetLang, setSourceLang, setTargetLang, sourceOptions, targetOptions, swapLanguages } = useLanguageSelector({ initialSource: 'hu', initialTarget: 'en-US' });
  const [ocrText, setOcrText] = useState('');
  const [translatedText, setTranslatedText] = useState('');

  function onBrowse() { fileRef.current?.click(); }
  function onFile(e) {
    const f = e.target.files && e.target.files[0];
    setFile(f || null);
    setPreview(f ? URL.createObjectURL(f) : null);
    setMessage('');
    setOcrText('');
    setTranslatedText('');
    // Do not auto-run OCR; wait for user to press Fordítás
  }

  async function doOCRAndTranslate() {
    if (!file && !preview) return setMessage('Válassz egy képet');
    setBusy(true); setMessage('OCR folyamat...');
    try {
      const langMap = {
        'en-US': 'eng', el: 'ell', de: 'deu', fr: 'fra', hu: 'hun', es: 'spa', it: 'ita', pt: 'por', ru: 'rus', ja: 'jpn', ko: 'kor', zh: 'chi_sim'
      };
      // try worker API first
      let text = '';
      const sourceCode = sourceLang?.code || 'en-US';
      const baseSourceCode = sourceCode.split('-')[0];
      const tessLang = langMap[baseSourceCode] || 'eng';
      console.log('OCR language:', tessLang, 'from sourceCode:', sourceCode);
      setMessage(`OCR folyamat (${tessLang})...`);
      // Ezt a nyelvet inicializálja a tesseract.js
        try {
          const res = await Tesseract.recognize(preview, tessLang);
          text = res && res.data ? res.data.text : (res && res.text) || '';
          console.log('(fallback) OCR eredmény hossza:', text.length, 'legelső 200 karakter:', text.substring(0, 200));
        } catch (recErr) {
          throw new Error('OCR hiba: ' + (recErr && recErr.message ? recErr.message : recErr));
      }
  setOcrText(text);
      // Most küldjük a felismert szöveget a DeepL API-nek
      setMessage(m => m + ' Fordítás...');
      const resp = await fetch('http://localhost:3001/translate', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, source_lang: sourceLang?.code || sourceLang, target_lang: targetLang?.code || targetLang })
      });
      if (!resp.ok) {
        const txt = await resp.text(); setMessage('Fordítási hiba: ' + txt); setBusy(false); return;
      }
  const json = await resp.json();
  const translated = (json && json.translation) || json || '';
  setTranslatedText(translated);
  setMessage('Kész — fordítás kész');
    } catch (err) {
      setMessage('Hiba: ' + (err.message || err));
    }
    setBusy(false);
  }

  return (
    <div id="fordito" className='centered'>
    <div className='translateContainer translate-file'>
      <LanguageSelector
        sourceLang={sourceLang}
        targetLang={targetLang}
        setSourceLang={setSourceLang}
        setTargetLang={setTargetLang}
        sourceOptions={sourceOptions}
        targetOptions={targetOptions}
        swapLanguages={swapLanguages}
      />


      <input ref={fileRef} type="file" accept="image/*" style={{ display: 'none' }} onChange={onFile} />
      {!file ? (
        <div className='browse-files'>
          <button onClick={onBrowse}>Fájlok böngészése</button>
          <div style={{ marginTop: 12 }}>{message}</div>
        </div>
      ) : (
        <div style={{ marginTop: 12, width: '100%', maxWidth: 720 }}>
          <div className="card" style={{ padding: 16, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              {preview && <img src={preview} alt="preview" style={{ width: 80, height: 80, objectFit: 'cover' }} />}
              <div>
                <div style={{ fontWeight: 600 }}>{file.name}</div>
                <div style={{ fontSize: 12, color: '#666' }}>{(file.size / 1024).toFixed(1)} KB</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={doOCRAndTranslate} disabled={busy || !preview}>{busy ? 'Fut...' : 'Fordítás'}</button>
              <button onClick={() => { setFile(null); setPreview(null); setMessage(''); }} title="Törlés">✕</button>
            </div>
          </div>
          <div style={{ marginTop: 30, textAlign: 'center'}}>{message}</div>
          <div style={{ marginTop: 12 }}>
            {/* <textarea value={ocrText} readOnly rows={4} style={{ width: '100%' }} placeholder="Felismert szöveg" /> */}
            <textarea value={translatedText} readOnly rows={10} style={{ width: '100%', textAlign: 'center', height: 'min-content' }} placeholder="Lefordított szöveg" />
          </div>
        </div>
      )}
      </div>
    </div>
  );
};

export default TranslateImg;