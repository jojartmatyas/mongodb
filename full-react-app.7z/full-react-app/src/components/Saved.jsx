import React, { useEffect, useState } from 'react';
import './Saved.scss';

const Saved = ({ user }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) return;
    const fetchSaved = async () => {
      setLoading(true);
      try {
        const u = encodeURIComponent(user.username);
        const res = await fetch(`/api/translations?user=${u}`);
        const data = await res.json();
        if (data.ok) setItems(data.translations || []);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    };
    fetchSaved();
  }, [user]);

  if (!user) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Nem vagy bejelentkezve.</h2>
        <p>Kérlek jelentkezz be, hogy megtekinthesd és elmenthesd a fordításokat.</p>
        <a href="/login">Bejelentkezés</a>
      </div>
    );
  }

  return (
    <div className="saved-root">
      <div className="saved-header">
        <h2>Mentett fordítások</h2>
        <div className="saved-user">{user.username}</div>
      </div>

      {loading && <div className="saved-loading">Töltés...</div>}

      {!loading && items.length === 0 && (
        <div className="saved-empty">Nincs mentett fordításod.</div>
      )}

      <ul className="saved-list">
        {items.map((it) => (
          <li key={it._id} className="saved-item">
            <div className="saved-meta">
              <span className="saved-time">{new Date(it.createdAt).toLocaleString()}</span>
            </div>
            <div className="saved-content">
              <div className="saved-source"><strong>Forrás:</strong> {it.text}</div>
              <div className="saved-translation"><strong>Fordítás:</strong> {it.translation}</div>
              <div className="saved-langs"><strong>Nyelvek:</strong> {it.source_lang} → {it.target_lang}</div>
            </div>
            <div className="saved-actions">
              <button
                className="saved-delete"
                onClick={async () => {
                  if (!confirm('Biztosan törlöd a fordítást?')) return;
                  try {
                    const res = await fetch(`/api/translations/${it._id}`, {
                      method: 'DELETE',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ username: user.username }),
                    });
                    const data = await res.json();
                    if (data.ok) {
                      setItems(prev => prev.filter(x => x._id !== it._id));
                    } else {
                      alert(data.msg || 'Törlés sikertelen');
                    }
                  } catch (e) {
                    alert('Hiba: ' + e.message);
                  }
                }}
              >Törlés</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Saved;