import React from 'react'
import { Link } from 'react-router-dom'
import './ModeSelect.scss'

const ModeButton = (p) => {
    return (
      <Link to={p.link}>
        <button className='mode'>
            <img src={p.img} style={{height: '40px', float: 'left', marginRight: '10px'}}/>
            <div className="mode-title">{p.title}</div>
        </button>
      </Link>
    )
}

const ModeSelect = () => {
  return (
    <div id="modeSelect" className='centered'>
        <ModeButton
        img="https://res.cloudinary.com/dguf0juur/image/upload/v1763629114/szoveg_hsvon1.svg"
        title="Szöveges mód"
  link="/translate/"
        />
        <ModeButton
        img="https://res.cloudinary.com/dguf0juur/image/upload/v1763629112/doksi_acjyuy.svg"
        title="Doksi mód"
        link="/translate/docs"
        />
        <ModeButton
        img="https://res.cloudinary.com/dguf0juur/image/upload/v1763629113/kep_tibpsq.svg"
        title="Kép fordítása"
        link="/translate/img"
        />
    </div>
  )
}

export default ModeSelect