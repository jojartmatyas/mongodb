import React from 'react';
import Footer from './components/Footer.jsx';

export default function App() {
  return (
    <div className="app-shell">
      <main className="content">
      </main>
      <Footer />
    </div>
  );
}
